import axios from "axios";
import React, { useEffect, useRef } from "react"
import { useState } from "react";

const UserInfo = ({ userId }) => {
    const [userData, setUserData] = useState(null);
  
    const getUser = async () => {
      try {
        const response = await axios.get(
          'https://ribu-backend.civitaseterna.com/User/48'
        );
        const userData = response.data;
  
        setUserData(userData);
      } catch (error) {
        // Bir hata oluştuysa burada işleyebilirsiniz.
      }
    };
  
    // getUser fonksiyonunu her 5 saniyede bir çalıştırın.
    const interval = useRef();
    useEffect(() => {
      interval.current = setInterval(getUser, 1000);
      return () => clearInterval(interval.current);
    }, []);

    return (

        <>
            <div className="info-area">
                <div className="info">
                    <h5>Balance:</h5>
                    {userData && <p>${userData.unRealBalance}</p>}
                </div>
                <div className="info">
                    <h5>Challenge Status:</h5>
                    {userData && <p>{userData.challenge === 1 ? "Discover" : userData.challenge === 2 ? "Approve" : "Ribu Trader"}</p>}
                </div>
                <div className="info">
                    <h5>Monthly Goal:</h5>
                    {userData && <p>%{10 - userData.monthlyPnL} kaldı!</p>}
                </div>
                <div className="info">
                    <h5>Daily Challenge Stop:</h5>
                    {userData &&<p>%{5 - userData.dailyPnL} kaldı!</p>}
                </div>
                <div className="info">
                    <h5>Monthly Challenge Stop:</h5>
                    {userData &&<p>%{10 + userData.monthlyPnL} kaldı!</p>}
                </div>
                <div className="info">
                    <h5>Leaderboard:</h5>
                    <p>17.Sıradasın!</p>
                </div>
                <div className="info">
                    <h5>Account PNL:</h5>
                    {userData &&<p>%{(userData.pnL * 100).toFixed(3)}</p>}
                </div>
            </div>
        </>

    )
}

export default UserInfo;