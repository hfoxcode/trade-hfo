import React from "react"

export default function Button() {
    return (
        <button>Berkay</button>
    )
}