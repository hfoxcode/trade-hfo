import React from "react"
import RibuBiggerLogo from "../img/ribu-bigger-logo.png"

export default function AboutUs() {
    return (
        <section className="about-us">
            <div className="image-area">
                <img src={RibuBiggerLogo} alt = "ribu bigger logo"/>
            </div>
            <div className="about-us-container">
                <div className="title">

                </div>
                <div className="row">
                    <div className="row-title">
                        Biz Kimiz?
                    </div>
                    <div className="row-description">
                        Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.
                    </div>
                </div>
                <div className="row">
                    <div className="row-title">
                        Çalışma Mekanizması
                    </div>
                    <div className="row-description">
                        Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.
                    </div>
                </div>
                <div className="row">
                    <div className="row-title">
                        Avantajlar
                    </div>
                    <div className="row-description">
                        Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.
                    </div>
                </div>
            </div>


        </section>
    )
}