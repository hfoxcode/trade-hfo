import React from "react"
import bitcoin from "../img/bitcoin.png";
import star from "../img/star.png";
import searchIcon from "../img/search.png"

export default function Markets() {
    return (
        <section className="markets">
            <div className="row">
                <div className="title-area">
                    <div className="title">Markets</div>
                    <div classname="button">Markets Overview</div>
                </div>
                <div className="table-area">
                    <div className="column">
                        <div className="table-title">
                            Highlight Coin
                        </div>
                        <div className="table">
                            <ul>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="column">
                        <div className="table-title">
                            Top Gainers
                        </div>
                        <div className="table">
                            <ul>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="column">
                        <div className="table-title">
                            Top Volume
                        </div>
                        <div className="table">
                            <ul>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="column">
                        <div className="table-title">
                            Most Traded in Ribu
                        </div>
                        <div className="table">
                            <ul>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                                <li>
                                    <div className="pair">
                                        <img src={bitcoin} alt="btc logo" />
                                        <div>BTC</div>
                                    </div>
                                    <div className="price">$19.000</div>
                                    <div className="gain">5%</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="choose-bar">
                    <div>
                        <img src={star} alt="star icon" />
                        <div>Favorites</div>
                    </div>
                    <div>
                        <img src={searchIcon} alt="search icon" />
                        <input type="text" placeholder="Search Coin Name" />
                    </div>
                </div>
                <div className="coin-table-area">
                    <table>
                        <thead>
                            <tr>
                                <td>Name</td>
                                <td>Price</td>
                                <td>
                                    <div>
                                        1h
                                    </div>
                                    <div>
                                        4h
                                    </div>
                                    <div>
                                        24h
                                    </div>
                                    <div>
                                        Change
                                    </div>
                                </td>
                                <td>24h Volume</td>
                                <td>Market Cap</td>
                                <td></td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div className="symbol-image">
                                        <img src={bitcoin} alt="bitcoin icon" />
                                    </div>
                                    <div className="symbol-ticker">
                                        BTC
                                    </div>
                                    <div className="symbol-full-name">
                                        Bitcoin
                                    </div>
                                </td>
                                <td>
                                    $19.000
                                </td>
                                <td>
                                    +0.17%
                                </td>
                                <td>
                                    19,732.13M
                                </td>
                                <td>
                                    $346,418.04M
                                </td>
                                <td>
                                    <div>Trade</div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="symbol-image">
                                        <img src={bitcoin} alt="bitcoin icon" />
                                    </div>
                                    <div className="symbol-ticker">
                                        BTC
                                    </div>
                                    <div className="symbol-full-name">
                                        Bitcoin
                                    </div>
                                </td>
                                <td>
                                    $19.000
                                </td>
                                <td>
                                    +0.17%
                                </td>
                                <td>
                                    19,732.13M
                                </td>
                                <td>
                                    $346,418.04M
                                </td>
                                <td>
                                    <div>Trade</div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="symbol-image">
                                        <img src={bitcoin} alt="bitcoin icon" />
                                    </div>
                                    <div className="symbol-ticker">
                                        BTC
                                    </div>
                                    <div className="symbol-full-name">
                                        Bitcoin
                                    </div>
                                </td>
                                <td>
                                    $19.000
                                </td>
                                <td>
                                    +0.17%
                                </td>
                                <td>
                                    19,732.13M
                                </td>
                                <td>
                                    $346,418.04M
                                </td>
                                <td>
                                    <div>Trade</div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="symbol-image">
                                        <img src={bitcoin} alt="bitcoin icon" />
                                    </div>
                                    <div className="symbol-ticker">
                                        BTC
                                    </div>
                                    <div className="symbol-full-name">
                                        Bitcoin
                                    </div>
                                </td>
                                <td>
                                    $19.000
                                </td>
                                <td>
                                    +0.17%
                                </td>
                                <td>
                                    19,732.13M
                                </td>
                                <td>
                                    $346,418.04M
                                </td>
                                <td>
                                    <div>Trade</div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="symbol-image">
                                        <img src={bitcoin} alt="bitcoin icon" />
                                    </div>
                                    <div className="symbol-ticker">
                                        BTC
                                    </div>
                                    <div className="symbol-full-name">
                                        Bitcoin
                                    </div>
                                </td>
                                <td>
                                    $19.000
                                </td>
                                <td>
                                    +0.17%
                                </td>
                                <td>
                                    19,732.13M
                                </td>
                                <td>
                                    $346,418.04M
                                </td>
                                <td>
                                    <div>Trade</div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="symbol-image">
                                        <img src={bitcoin} alt="bitcoin icon" />
                                    </div>
                                    <div className="symbol-ticker">
                                        BTC
                                    </div>
                                    <div className="symbol-full-name">
                                        Bitcoin
                                    </div>
                                </td>
                                <td>
                                    $19.000
                                </td>
                                <td>
                                    +0.17%
                                </td>
                                <td>
                                    19,732.13M
                                </td>
                                <td>
                                    $346,418.04M
                                </td>
                                <td>
                                    <div>Trade</div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="symbol-image">
                                        <img src={bitcoin} alt="bitcoin icon" />
                                    </div>
                                    <div className="symbol-ticker">
                                        BTC
                                    </div>
                                    <div className="symbol-full-name">
                                        Bitcoin
                                    </div>
                                </td>
                                <td>
                                    $19.000
                                </td>
                                <td>
                                    +0.17%
                                </td>
                                <td>
                                    19,732.13M
                                </td>
                                <td>
                                    $346,418.04M
                                </td>
                                <td>
                                    <div>Trade</div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div className="symbol-image">
                                        <img src={bitcoin} alt="bitcoin icon" />
                                    </div>
                                    <div className="symbol-ticker">
                                        BTC
                                    </div>
                                    <div className="symbol-full-name">
                                        Bitcoin
                                    </div>
                                </td>
                                <td>
                                    $19.000
                                </td>
                                <td>
                                    +0.17%
                                </td>
                                <td>
                                    19,732.13M
                                </td>
                                <td>
                                    $346,418.04M
                                </td>
                                <td>
                                    <div>Trade</div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    )
}