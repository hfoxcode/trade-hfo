import axios from "axios";
import React, { useEffect } from "react"
import { useState } from "react";
import CalculatorPopup from "./CalculatorPopup";
import PnlPopup from "./PnlPopup";
import calculatorIcon from "../img/calculator.png"

export default function TradeArea() {

    const [openCalculatorPopup, setOpenCalculatorPopup] = useState(false);
    // const [openTakeProfitPopup, setOpenTakeProfitPopup] = useState(false);
    const [openPnlPopup, setOpenPnlPopup] = useState(false);
    const [positionType, setPositionType] = useState(0);
    const [positionDirection, setPositionDirection] = useState(0);
    const [userId, setUserId] = useState(48);
    const [percentage1, setPercentage1] = useState(5);
    const [avblBalance, setAvblBalance] = useState();


    const [pair, setPair] = useState(1);
    const [size, setSize] = useState(0.1);

    const [price, setPrice] = useState(0);

    // const handleSizeChange = (newSize) => {
    //     setSize(newSize);
    //     setPercentage1((newSize / avblBalance) * 100);
    //   }

    useEffect(() => {
        const socket = new window.WebSocket('wss://stream.binance.com:9443/ws/btcusdt@ticker');

        socket.onmessage = event => {
            const data = JSON.parse(event.data);
            const number = Number(data.c);
            setPrice(number);
        };

        // Komponentin kaldırılacağı zaman (örneğin, bir sayfadan çıkıldığında),
        // websocket bağlantısını kapatın.
        return () => socket.close();
    }, []);

    async function marketBuy(event) {
        event.preventDefault();

        try {
            await axios.post(`https://ribu-backend.civitaseterna.com/Positions/Buy?userId=${userId}&pair=${pair}&size=${size / price}
            `);
            console.log("iuv");
            // İşlem başarılıysa burada bir mesaj gösterebilir veya bir işlem yapabilirsiniz.
        } catch (error) {
            // Bir hata oluştuysa burada işleyebilirsiniz.
        }
    }

    async function marketSell(event) {
        event.preventDefault();

        try {
            await axios.post(`https://ribu-backend.civitaseterna.com/Positions/Sell?userId=${userId}&pair=${pair}&size=${size / price}`);
            console.log("iuv");
            // İşlem başarılıysa burada bir mesaj gösterebilir veya bir işlem yapabilirsiniz.
        } catch (error) {
            // Bir hata oluştuysa burada işleyebilirsiniz.
        }
    }

    useEffect(() => {
        const getUser = async () => {
            try {
                const response = await axios.get('https://ribu-backend.civitaseterna.com/User/' + userId);
                const realBalance = Number(response.data.realBalance);
                const leverage = Number(response.data.leverage);

                setAvblBalance(realBalance * leverage);


            } catch (error) {
                // Bir hata oluştuysa burada işleyebilirsiniz.
            }
        }

        // getUser fonksiyonunu her 1000 milisaniye (yani 1 saniye) bir çalıştırın.
        const interval = setInterval(getUser, 1000);

        // Komponentin kaldırılacağı zaman (örneğin, bir sayfadan çıkıldığında),
        // interval değişkenini sıfırlayın.
        return () => clearInterval(interval);
    }, []);

        // const handleSizeChange = (newSize) => {
    //     setSize(Number(newSize));
    //     setPercentage1((newSize / avblBalance) * 100);
    // }

    useEffect(() => {
        setSize(avblBalance * (percentage1 / 100));
    }, [percentage1, avblBalance]);



    const handleSizeChange = (newSize) => {
        if (newSize > avblBalance) {
            setSize(avblBalance);
        } else if (newSize === "") {
            setSize("");
        } else {
            setSize(newSize);
        }
        setPercentage1(newSize / avblBalance * 100);
    }

    const handlePercentageChange = (newPercentage) => {
        if (newPercentage > 100) {
            setPercentage1(100);
        } else if (newPercentage === "") {
            setPercentage1("");
        } else {
            setPercentage1(newPercentage);
        }
        setSize(newPercentage / 100 * avblBalance);
    }

    return (
        <div className="trade-area">
            <div className="buy-sell-buttons">
                <div onClick={() => setPositionDirection(0)} className={positionDirection === 0 ? "button yellowButton" : "button grayButton"}>BUY</div>
                <div onClick={() => setPositionDirection(1)} className={positionDirection === 0 ? "button grayButton" : "button yellowButton"}>SELL</div>
            </div>
            <div className="order-type-area">
                <div className={positionType === 0 ? "order-type colorYellow" : "order-type"} onClick={() => setPositionType(0)}>Limit</div>
                <div className={positionType === 1 ? "order-type colorYellow" : "order-type"} onClick={() => setPositionType(1)}>Market</div>
                <div className={positionType === 3 ? "order-type colorYellow" : "order-type"} onClick={() => setPositionType(3)}>Stop Limit</div>
            </div>

            <CalculatorPopup open={openCalculatorPopup} onClose={() => setOpenCalculatorPopup(false)} />
            {/* <TakeProfitPopup open={openTakeProfitPopup} onClose={() => setOpenTakeProfitPopup(false)} /> */}
            <PnlPopup open={openPnlPopup} onClose={() => setOpenPnlPopup(false)} />



            <div className="amount-area">
                <div className="avlbl">
                    <div className="avlbl-title">Avbl</div>
                    <div className="avlbl-amount">{avblBalance} USDT</div>
                    <div className="calculator-icon-area" onClick={() => setOpenCalculatorPopup(true)}>
                        <img src={calculatorIcon} alt="calculator icon" />
                    </div>
                </div>

                {positionType === 3 ?

                    <label className="trade-area-label">
                        <div className="input-area">
                            <div className="input-area-title">
                                Stop Price
                            </div>
                            <div className="input">
                                <input type="text" name="stop-price" placeholder='Stop Price' />
                            </div>
                            <div className="input-area-pair">USDT</div>
                        </div>


                    </label>

                    : null}

                {positionType === 0 || 3 ?

                    <label className="trade-area-label">
                        <div className="input-area">
                            <div className="input-area-title">
                                Price
                            </div>
                            <div className="input">
                                <input type="text" name="price" placeholder='price' />
                            </div>
                            <div className="last-btn">Last</div>
                            <div className="input-area-pair">USDT</div>
                        </div>


                    </label>

                    : null

                }





                <label className="trade-area-label">
                    <div className="input-area">
                        <div className="input-area-title">
                            Size
                        </div>
                        <div className="input">
                        <input type="number" max={avblBalance} value={parseFloat(size).toFixed(2)} placeholder="size" onChange={event => {
  setSize(event.target.value);
  handleSizeChange(event.target.value);
}} />
                        </div>
                        <div className="input-area-pair">USDT</div>
                    </div>


                </label>
                <div className="amount-bar">
                    <div className="selection-bar">
                        <input type="range" onChange={(event) => {
                            setPercentage1(event.target.value);
                            handlePercentageChange(event.target.value);
                        }} value={percentage1} />
                        <div style={{ width: `${percentage1}%` }}>{Number(percentage1).toFixed(2)}%</div>
                    </div>
                </div>
            </div>
            <div className="leverage-area">
                <div className="leverage-bar">
                    <div className="leverage-bar-title">
                        Account Leverage:
                    </div>
                    <select>
                        <option>1x</option>
                        <option>3x</option>
                        <option>5x</option>
                        <option>10x</option>
                        <option>25x</option>
                        <option>50x</option>
                        <option>75x</option>
                        <option>100x</option>
                    </select>
                </div>
            </div>
            <div className="button-area">
                {positionDirection === 0 ?
                    <div className="button" onClick={(event) => marketBuy(event)}>Buy/Long BTC</div>
                    :
                    <div className="button" onClick={(event) => marketSell(event)}>Short/Sell BTC</div>
                }

            </div>
            <div className="leverage-info-area">
                <div className="leverage-info">
                    High leverage in trading carries significant risk, particularly in volatile markets and during fast price movements, and can result in significant losses. The higher the leverage ratio, the greater the potential loss.
                </div>
            </div>
        </div>
    )
}