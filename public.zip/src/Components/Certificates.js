import React from "react"
import { Link } from "react-router-dom";
import payoutCertificates from "../img/tff-payout-certificates-image-container-area.png";

export default function Certificates() {
    return (
        <section className="certificates">
            <div className="column first-column">
                <div className="option">Profile</div>
                <div className="option">Trading Area</div>
                <div className="option">
                    <Link to="../roadmap">
                        Roadmap
                    </Link>
                </div>


                <div className="option">
                    <Link to="../intro-roadmap">
                        How To Start
                    </Link>
                </div>

                <div className="option">
                    <Link to="../certificates">
                        Certificates
                    </Link>
                </div>

                <div className="option">
                    <Link to="../statistics">Statistics</Link>
                </div>

                <div className="option">
                    <Link to="../payment-area">Payment Area</Link>
                </div>

                <div className="option">
                    <Link to="../leaderboard">Leaderboard</Link>
                </div>

                <div className="option">Settings</div>
            </div>
            <div className="certificates-container">
                <div className="button-area">
                    <div>
                        Passed Certificates
                    </div>
                    <div>
                        Payout Certificates
                    </div>
                    <div>
                        Leaderboard Certificates
                    </div>
                </div>
                <div className="certificates-area">
                    <img src={payoutCertificates} alt="payout certificates" />
                </div>
            </div>
        </section>
    )
}