import React from "react"
import JesseLivermore from "../img/jesse_livermore.png"

export default function HowRibuDoingThis() {
    return (
        <section className="how-ribu-doing-this">
            <div className="row">
                <div className="column">
                    <div className="description">
                        Ribu sizi iki aşamalı bir challenge'a sokarak trade yeteneklerinizi ölçer. Bu chalenge'ları başarı ile tamamladığınız taktirde siz de artık sertifikalı bir Ribu trader olarak gerçek bir fon yönetmeye başlarsınız. Elde ettiğiniz karın %75'ini her hafta çekebilirsiniz!
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="card">
                    
                </div>
            </div>
        </section>
    )
}