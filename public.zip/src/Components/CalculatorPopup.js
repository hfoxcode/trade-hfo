import React, { useState } from "react"

const CalculatorPopup = ({ open, onClose }) => {
    if (!open) return null

    return (
        <div onClick={onClose} className="overlay-two">
            <div onClick={(e) => {
                e.stopPropagation()
            }} className="popup_container">
                <div className="calculator-popup">
                    <div className="row">
                        <div className="button">
                            Buy
                        </div>
                        <div className="button">
                            Sell
                        </div>
                    </div>
                    <div className="row">
                        <div className="column">
                            <div className="order-type-area">
                                <div className="order-type colorYellow">Limit</div>
                                <div className="order-type colorYellow">Market</div>
                            </div>
                            <div className="avlbl">
                                <div className="avlbl-title">Avbl</div>
                                <div className="avlbl-amount">0.000000000 USDT</div>
                            </div>
                            <label className="trade-area-label">
                                <div className="input-area">
                                    <div className="input-area-title">
                                        Entry Price
                                    </div>
                                    <div className="input">
                                        <input type="text" name="stop-price" placeholder='Stop Price' />
                                    </div>
                                    <div className="input-area-pair">USDT</div>
                                </div>


                            </label>
                            <label className="trade-area-label">
                                <div className="input-area">
                                    <div className="input-area-title">
                                        Take Profit:
                                    </div>
                                    <div className="input">
                                        <input type="text" name="stop-price" placeholder='Stop Price' />
                                    </div>
                                    <div className="input-area-pair">USDT</div>
                                </div>


                            </label>
                            <label className="trade-area-label">
                                <div className="input-area">
                                    <div className="input-area-title">
                                        Stop Loss:
                                    </div>
                                    <div className="input">
                                        <input type="text" name="stop-price" placeholder='Stop Price' />
                                    </div>
                                    <div className="input-area-pair">USDT</div>
                                </div>


                            </label>
                            <label className="trade-area-label">
                                <div className="input-area">
                                    <div className="input-area-title">
                                        Size:
                                    </div>
                                    <div className="input">
                                        <input type="text" name="size" placeholder='Size' />
                                    </div>
                                    <div className="input-area-pair">USDT</div>
                                </div>


                            </label>
                            <div className="amount-bar">
                                <div className="line-area">
                                    <div className="dot">

                                    </div>
                                    <div className="line2">

                                    </div>
                                </div>
                                <div className="line-area">
                                    <div className="dot">

                                    </div>
                                    <div className="line2">

                                    </div>
                                </div>
                                <div className="line-area">
                                    <div className="dot">

                                    </div>
                                    <div className="line2">

                                    </div>
                                </div>
                                <div className="line-area">
                                    <div className="dot">

                                    </div>
                                    <div className="line2">

                                    </div>
                                </div>
                                <div className="line-area">
                                    <div className="dot">

                                    </div>
                                </div>
                            </div>
                            <div className="leverage-area">
                                <div className="leverage-bar">
                                    <div className="leverage-bar-title">
                                        Account Leverage:
                                    </div>
                                    <select>
                                        <option>1x</option>
                                        <option>3x</option>
                                        <option>5x</option>
                                        <option>10x</option>
                                        <option>25x</option>
                                        <option>50x</option>
                                        <option>75x</option>
                                        <option>100x</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div className="column">
                            <div className="tp-sl-area">
                                <div className="bigger-title">Take Profit</div>
                                <div className="row">
                                    <div className="column">
                                        <div className="profit-usdt">+54 USDT</div>
                                        <div className="profit-split">
                                            <div className="title">
                                                Profit Split
                                            </div>
                                            <div className="challenge-finish-bar-area">
                                                <div>
                                                    Challenge'ın tamamlanmasına %2 Profit kaldı!
                                                </div>
                                                <div className="line-area">
                                                    <div className="line" id="line1"></div>
                                                    <div className="line" id="line2"></div>
                                                </div>
                                            </div>
                                            <div className="challenge-finish-bar-area">
                                                <div>
                                                    Stop kısıtlamasının bitmesine -%6 kaldı!
                                                </div>
                                                <div className="line-area">
                                                    <div className="line" id="line1"></div>
                                                    <div className="line" id="line2"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="tp-sl-area">
                                <div className="bigger-title">Stop Loss</div>
                                <div className="row">
                                    <div className="column">
                                        <div className="profit-usdt">-104 USDT</div>
                                        <div className="profit-split">
                                            <div className="title">
                                                Profit Split
                                            </div>
                                            <div className="challenge-finish-bar-area">
                                                <div>
                                                    Challenge'ın tamamlanmasına %8 Profit kaldı!
                                                </div>
                                                <div className="line-area">
                                                    <div className="line" id="line1"></div>
                                                    <div className="line" id="line2"></div>
                                                </div>
                                            </div>
                                            <div className="challenge-finish-bar-area">
                                                <div>
                                                    Challenge Başarısız!
                                                    Stop kısıtlamasının bitmesine -%3 kaldı!
                                                </div>
                                                <div className="line-area">
                                                    <div className="line" id="line1"></div>
                                                    <div className="line" id="line2"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="button-area">
                            <div className="button">Buy BTC</div>
                        </div>
                    </div>
                </div>
                <p onClick={onClose} className="close_popup">X</p>
            </div>

        </div>
    )
}

export default CalculatorPopup;