import axios from "axios";
import React from "react"
import { useState } from "react";
import { useEffect } from "react";
import resize from "../img/resize.png";
import PnlPopup from "./PnlPopup";
import TakeProfitPopup from "./TakeProfitPopup";

export default function PositionsData() {
    const [positionsData, setPositionsData] = useState([]);
    const [userId, setUserId] = useState("48");
    const [price, setPrice] = useState();
    const [ethPrice, setEthPrice] = useState();
    const [bnbPrice, setBnbPrice] = useState();
    const [monthlyPnl, setMonthlyPnl] = useState();
    const [accountPnl, setAccountPnl] = useState();
    const [openPnlPopup, setOpenPnlPopup] = useState(false);
    const [openTakeProfitPopup, setOpenTakeProfitPopup] = useState(false);
    const [openedItemIndex, setOpenedItemIndex] = useState(-1);




    useEffect(() => {
        const socket = new window.WebSocket('wss://stream.binance.com:9443/ws/btcusdt@ticker');

        socket.onmessage = event => {
            const data = JSON.parse(event.data);
            const number = Number(data.c);
            const fixedNumber = number.toFixed(1);
            setPrice(fixedNumber);
        };

        // Komponentin kaldırılacağı zaman (örneğin, bir sayfadan çıkıldığında),
        // websocket bağlantısını kapatın.
        return () => socket.close();
    }, []);

    useEffect(() => {
        const socket = new window.WebSocket('wss://stream.binance.com:9443/ws/ethusdt@ticker');

        socket.onmessage = event => {
            const data = JSON.parse(event.data);
            const number = Number(data.c);
            const fixedNumber = number.toFixed(1);
            setEthPrice(fixedNumber);
        };

        // Komponentin kaldırılacağı zaman (örneğin, bir sayfadan çıkıldığında),
        // websocket bağlantısını kapatın.
        return () => socket.close();
    }, []);

    useEffect(() => {
        const socket = new window.WebSocket('wss://stream.binance.com:9443/ws/bnbusdt@ticker');

        socket.onmessage = event => {
            const data = JSON.parse(event.data);
            const number = Number(data.c);
            const fixedNumber = number.toFixed(1);
            setBnbPrice(fixedNumber);
        };

        // Komponentin kaldırılacağı zaman (örneğin, bir sayfadan çıkıldığında),
        // websocket bağlantısını kapatın.
        return () => socket.close();
    }, []);

    useEffect(() => {
        const getPositionsData = async () => {
            const result = await axios.get('https://ribu-backend.civitaseterna.com/Positions/UserPositions/' + userId);
            setPositionsData(result.data);
        };

        getPositionsData();
        const interval = setInterval(getPositionsData, 5000);

        return () => clearInterval(interval); // fetch data every 1 second
    }, []);

    useEffect(() => {
        const getUser = async () => {
            try {
                const response = await axios.get('https://ribu-backend.civitaseterna.com/User/' + userId);
                const monthlyPnl = response.data.monthlyPnL;
                // const accountPnl = response.data.pnL;
                const accountPnl = Number(response.data.pnL);

                setMonthlyPnl(monthlyPnl);
                setAccountPnl(accountPnl);
            } catch (error) {
                // Bir hata oluştuysa burada işleyebilirsiniz.
            }
        }

        // getUser fonksiyonunu her 1000 milisaniye (yani 1 saniye) bir çalıştırın.
        const interval = setInterval(getUser, 1000);

        // Komponentin kaldırılacağı zaman (örneğin, bir sayfadan çıkıldığında),
        // interval değişkenini sıfırlayın.
        return () => clearInterval(interval);
    }, []);


    return (

        <>
            <TakeProfitPopup
                open={openTakeProfitPopup}
                onClose={() => setOpenTakeProfitPopup(false)}
                item={positionsData[openedItemIndex]}
                price={price}
                ethPrice={ethPrice}
                bnbPrice={bnbPrice}
            />
            <PnlPopup
                open={openPnlPopup}
                onClose={() => setOpenPnlPopup(false)}
                item={positionsData[openedItemIndex]}
                price={price}
                ethPrice={ethPrice}
                bnbPrice={bnbPrice}
            />

            {
                positionsData.map((item, index) => (
                    <>

                        <tr key={item.pair === 1 ? "BTCUSDT" : item.pair === 2 ? "ETHUSDT" : item.pair === 3 ? "BNBUSDT" : null}>
                            <td>{item.pair === 1 ? "BTCUSDT" : item.pair === 2 ? "ETHUSDT" : item.pair === 3 ? "BNBUSDT" : null}</td>
                            <td className={item.type === "LONG" ? "colorGreen width75" : "colorShort width75"}>+{Number(item.size * item.avgEntryPrice).toFixed(2)} USDT</td>
                            <td className="width54">{item.avgEntryPrice}</td>
                            <td className="width54">{item.avgEntryPrice}</td>
                            <td className="width54">{Number((item.avgEntryPrice * (100 - (10 + accountPnl))) / 100).toFixed(2)}</td>
                            <td className={item.pnL * price >= 0 ? "colorGreen width148" : "colorShort width148"}>
                                <div>
                                    {(item.pnL * price) > "0" ? "+" : (item.pnL * price) === "0" ? null : null}{(item.pnL * (item.pair === "1" ? price : item.pair === "2" ? ethPrice : bnbPrice)).toFixed(2)} USDT ({(item.pnL * price) > "0" ? "+" : (item.pnL * price) === "0" ? null : null}{Number(item.pnL * 100).toFixed(2)}) %
                                </div>
                                <div onClick={() => {
                                    setOpenedItemIndex(index);
                                    setOpenPnlPopup(true);
                                }}>
                                    <img src={resize} alt="resize icon" />
                                </div>
                            </td>
                            <td>
                                <div className="close-positions-button">
                                    Market
                                </div>
                                <div className="close-positions-button">
                                    <div>Limit</div>
                                </div>

                            </td>
                            <td>
                                <div className="tp-area" onClick={() => {
                                    setOpenTakeProfitPopup(true);
                                    setOpenedItemIndex(index);
                                    
                                }}>
                                    Take Profit
                                </div>
                            </td>
                        </tr>
                    </>

                ))
            }
        </>

    )
}