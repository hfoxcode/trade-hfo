import React from "react"
import testimonials from "../img/testimonials.png";

export default function HowItWorksDetailed() {
    return (
        <section className="how-it-works-detailed">
            <section className="what-is-ribu">
                <div className="column">
                    <div className="title">How Ribu Works?</div>
                    <div className="description">
                        Ribu, büyük fonlar yönetmeni sağlayan bir online prop trading platformu. Challenge'ları geç, trade etmeye başla. Kazandığının %75'i senin. Zararını ise biz karşılıyoruz.
                    </div>
                </div>
                <div className="column">
                    <div className="testimonials-container">
                        <img src={testimonials} alt="testimonials cards" />
                    </div>
                </div>
            </section>
            <section className="trading-objectives">
                <div className="row">
                    <div className="title">Trading Objectives</div>
                </div>
                <div className="row">
                    <div className="objective-card"></div>
                    <div className="objective-card"></div>
                    <div className="objective-card"></div>
                </div>


            </section>
        </section>
    )
}