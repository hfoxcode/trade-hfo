import React from "react"
import Challenger from "../Components/Challenger"

export default function ChallengerPage() {
    return(
        <>
        <Challenger/>
        </>
    )
}