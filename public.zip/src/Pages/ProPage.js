import React from "react"
import Pro from "../Components/Pro"

export default function ProPage() {
    return (
        <>
        <Pro/>
        </>
    )
}