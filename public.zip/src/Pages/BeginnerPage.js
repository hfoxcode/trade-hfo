import React from "react"
import Beginner from "../Components/Beginner"

export default function BeginnerPage() {
    return(
        <>
            <Beginner/>
        </>
    )
}