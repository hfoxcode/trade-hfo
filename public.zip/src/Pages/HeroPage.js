import React from "react"
import HeroContainer from "../Components/HeroContainer"
import ChallengeDesk from "../Components/ChallengeDesk"
import ChallengeSteps from "../Components/ChallengeSteps"
import Confidence from "../Components/Confidence"
import HowRibuDoingThis from "../Components/HowRibuDoingThis"
import AnimationComp from "../Components/AnimationComp"

export default function HeroPage() {
    return (
        <>
            <HeroContainer />
            <HowRibuDoingThis/>
            <ChallengeDesk />
            <ChallengeSteps />
        </>

    )
}