import React from "react"
import UserDashboard from "../Components/UserDashboard"

export default function UserDashboardPage() {
    return (
        <UserDashboard/>
    )

}
