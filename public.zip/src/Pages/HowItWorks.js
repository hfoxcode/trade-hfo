import React from "react"

export default function HowItWorks() {
    return(
        <>
        <section className="how-it-works">
            <section className="what-is-ribu">
                <div className="title">
                    What is Ribu?
                </div>
                
            </section>

            <section className="how-it-works-area">

            </section>

            <section className="why-ribu">
                
            </section>
        </section>
        </>
    )
}