import React from "react"
import Education from "../Components/Education"

export default function EducationPage() {
    return(
        <Education/>
    )
}