import React from "react"
import AboutUs from "../Components/AboutUs"

export default function AboutUsPage() {
    return (
        <AboutUs/>
    )
}