import React from "react"
import Quiz from "../Components/Quiz"

export default function QuizPage() {
    return (
        <Quiz/>
    )
}